package usp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.StreamCorruptedException;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Calendar;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

import org.json.simple.*;

public class WorkingThread extends Thread {

	// private static ConcurrentHashMap<String, String> bruteforceReports = new
	// ConcurrentHashMap<String, String>();;
	private static ConcurrentHashMap<String, String> ddosReports = new ConcurrentHashMap<String, String>();;
	private static Semaphore mutex = new Semaphore(1);

	final int TO = 10000;
	final int N = 20;

	Socket client;
	String clientIP;
	ConcurrentHashMap<String, String> myUsers;
	ConcurrentHashMap<String, Integer> bruteforceDetection;
	ConcurrentHashMap<String, Integer> ddosDetection;
	URL url;
	URL url1;
	HttpURLConnection con;
	HttpURLConnection con1;

	public WorkingThread(Socket client, ConcurrentHashMap<String, String> myUsers,
			ConcurrentHashMap<String, Integer> bruteforceDetection, ConcurrentHashMap<String, Integer> ddosDetection) {
		this.client = client;
		this.clientIP = client.getRemoteSocketAddress().toString().substring(1, 10);
		this.myUsers = myUsers;
		this.bruteforceDetection = bruteforceDetection;
		this.ddosDetection = ddosDetection;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void run() {

		try (ObjectOutputStream outToClient = new ObjectOutputStream(client.getOutputStream());
				ObjectInputStream inFromClient = new ObjectInputStream(client.getInputStream());) {

			client.setSoTimeout(TO); // wait 10s

			url1 = new URL("http://localhost:3000/checkclient");

			con1 = (HttpURLConnection) url1.openConnection();
			con1.setRequestMethod("POST");
			con1.setRequestProperty("Content-Type", "application/json");
			con1.setRequestProperty("Accept", "application/json");
			con1.setDoOutput(true);

			JSONObject obj1 = new JSONObject();

			obj1.put("username", "test");
			obj1.put("password", "test123");
			obj1.put("IPv4", clientIP);

			try (OutputStream os = con1.getOutputStream()) {
				byte[] input = obj1.toString().getBytes();
				os.write(input, 0, input.length);
				os.flush();
			}

			StringBuilder response1 = new StringBuilder();

			try (BufferedReader br = new BufferedReader(new InputStreamReader(con1.getInputStream(), "utf-8"))) {
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response1.append(responseLine.trim());
				}
			}

			System.out.println(response1.toString());
			String answer1 = response1.toString().substring(12, 16);

			if (!answer1.equals("true")) {
				String message = "you are not welcome here";
				outToClient.writeObject(message);
				outToClient.flush();
				throw new BanException();
			} else {
				outToClient.writeObject("Tried to connect as a client with an ip address: " + clientIP);
				outToClient.flush();
			}

			while (true) {

				try {

					String username = (String) inFromClient.readObject();
					String password = (String) inFromClient.readObject();

					if (myUsers.containsKey(username) && myUsers.get(username).equals(password)) {
						String message = "access approved";
						outToClient.writeObject(message);
						outToClient.flush();
						break;
					} else {
						if (!bruteforceDetection.containsKey(clientIP)) {
							bruteforceDetection.put(clientIP, 1);
							String message = "enter credentials again";
							outToClient.writeObject(message);
							outToClient.flush();
						} else {
							int temp = bruteforceDetection.get(clientIP);
							temp++;
							bruteforceDetection.remove(clientIP);
							bruteforceDetection.put(clientIP, temp);
							if (temp == N) {
								url = new URL("http://localhost:3000/report");

								con = (HttpURLConnection) url.openConnection();
								con.setRequestMethod("POST");
								con.setRequestProperty("Content-Type", "application/json");
								con.setRequestProperty("Accept", "application/json");
								con.setDoOutput(true);

								JSONObject obj = new JSONObject();

								Calendar calendar = Calendar.getInstance();
								int year = calendar.get(Calendar.YEAR);
								int month = calendar.get(Calendar.MONTH) + 1;
								int day = calendar.get(Calendar.DAY_OF_MONTH);

								String time = year + "-" + month + "-" + day;

								obj.put("username", "test");
								obj.put("password", "test123");
								obj.put("IPv4", clientIP);
								obj.put("attackType", "bruteforce");
								obj.put("timeStamp", time);

								try (OutputStream os = con.getOutputStream()) {
									byte[] input = obj.toString().getBytes();
									os.write(input, 0, input.length);
									os.flush();
								}

								StringBuilder response = new StringBuilder();

								try (BufferedReader br = new BufferedReader(
										new InputStreamReader(con.getInputStream(), "utf-8"))) {
									String responseLine = null;
									while ((responseLine = br.readLine()) != null) {
										response.append(responseLine.trim());
									}

									System.out.println(response.toString());

									String message = "you are not welcome here";
									outToClient.writeObject(message);
								}

							} else {
								String message = "enter credentials again";
								outToClient.writeObject(message);
								outToClient.flush();
							}

						}
					}

				} catch (SocketTimeoutException e) {
					if (!ddosDetection.containsKey(clientIP)) {
						ddosDetection.put(clientIP, 1);
						String message = "enter credentials again";
						outToClient.writeObject(message);
						outToClient.flush();
					} else {
						int temp = ddosDetection.get(clientIP);
						temp++;
						ddosDetection.remove(clientIP);
						ddosDetection.put(clientIP, temp);
						if (temp == N) {
							url = new URL("http://localhost:3000/report");

							con = (HttpURLConnection) url.openConnection();
							con.setRequestMethod("POST");
							con.setRequestProperty("Content-Type", "application/json");
							con.setRequestProperty("Accept", "application/json");
							con.setDoOutput(true);

							JSONObject obj = new JSONObject();

							Calendar calendar = Calendar.getInstance();
							int year = calendar.get(Calendar.YEAR);
							int month = calendar.get(Calendar.MONTH) + 1;
							int day = calendar.get(Calendar.DAY_OF_MONTH);

							String time = year + "-" + month + "-" + day;

							obj.put("username", "test");
							obj.put("password", "test123");
							obj.put("IPv4", clientIP);
							obj.put("attackType", "DoS");
							obj.put("timeStamp", time);

							try (OutputStream os = con.getOutputStream()) {
								byte[] input = obj.toString().getBytes();
								os.write(input, 0, input.length);
								os.flush();
							}

							StringBuilder response = new StringBuilder();

							try (BufferedReader br = new BufferedReader(
									new InputStreamReader(con.getInputStream(), "utf-8"))) {
								String responseLine = null;
								while ((responseLine = br.readLine()) != null) {
									response.append(responseLine.trim());
								}

								System.out.println(response.toString());

								String message = "you are not welcome here";
								outToClient.writeObject(message);

								break;

							}

						} else {
							String message = "enter credentials again";
							outToClient.writeObject(message);
							outToClient.flush();
						}
					}

				} catch (Exception e) {

				}
			}

		} catch (StreamCorruptedException e) {

			System.out.println("DDoS");

			try {
				Calendar calendar = Calendar.getInstance();
				int year = calendar.get(Calendar.YEAR);
				int month = calendar.get(Calendar.MONTH) + 1;
				int day = calendar.get(Calendar.DAY_OF_MONTH);

				String time = year + "-" + month + "-" + day;

				mutex.acquire();

				if (!(ddosReports.containsKey(clientIP) && ddosReports.get(clientIP).equals(time))) {

					ddosReports.put(clientIP, time);

					mutex.release();

					url = new URL("http://localhost:3000/report");

					con = (HttpURLConnection) url.openConnection();
					con.setRequestMethod("POST");
					con.setRequestProperty("Content-Type", "application/json");
					con.setRequestProperty("Accept", "application/json");
					con.setDoOutput(true);

					JSONObject obj = new JSONObject();

					obj.put("username", "test");
					obj.put("password", "test123");
					obj.put("IPv4", clientIP);
					obj.put("attackType", "DoS");
					obj.put("timeStamp", time);

					try (OutputStream os = con.getOutputStream()) {
						byte[] input = obj.toString().getBytes();
						os.write(input, 0, input.length);
						os.flush();
					}

					StringBuilder response = new StringBuilder();

					try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
						String responseLine = null;
						while ((responseLine = br.readLine()) != null) {
							response.append(responseLine.trim());
						}

						System.out.println(response.toString());

					}

				} else {
					mutex.release();
				}

			} catch (Exception e2) {

			}

		} catch (IOException e) {
			
		} catch (BanException e) {

		} catch (Exception e) {

		}

	}

}
