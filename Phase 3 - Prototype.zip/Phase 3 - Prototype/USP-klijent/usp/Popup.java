package usp;

import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextArea;


public class Popup extends JDialog{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JTextArea jta;
	
	public Popup(JFrame frame, String text) {
		super(frame, "Message from server", false);
		this.setBounds(frame.getX(), frame.getY()-70, 400, 70);
		this.setResizable(false);
		jta = new JTextArea();
		jta.setFont(new Font("Tahoma", Font.PLAIN, 13));
		jta.setBackground(SystemColor.controlHighlight);
		jta.setText(text);
		this.add(jta);
		setVisible(true);
	}
	
	public void setText(String text) {
		jta.setText(text);
	}
	
	public String getText() {
		return jta.getText();
	}
}
