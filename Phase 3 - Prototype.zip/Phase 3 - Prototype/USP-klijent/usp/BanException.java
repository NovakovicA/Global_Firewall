package usp;

public class BanException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String toString(){ return "User is banned";}
	
}
