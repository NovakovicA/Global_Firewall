package usp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class ClientFrame {

	private JFrame frame;
	private JTextField usernameField;
	private JTextField passwordField;
	private Socket serverSocket;
	private ObjectOutputStream outToServer;
	private ObjectInputStream inFromServer;
	private Popup dialog;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientFrame window = new ClientFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ClientFrame() {
		initialize();
		try {

			serverSocket = new Socket("localhost", 53000);
			outToServer = new ObjectOutputStream(serverSocket.getOutputStream());
			inFromServer = new ObjectInputStream(serverSocket.getInputStream());

			String temp = (String) inFromServer.readObject();

			dialog = new Popup(frame, temp);

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public Popup getDialog() {
		return dialog;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(SystemColor.text);
		frame.setResizable(false);
		frame.setForeground(SystemColor.text);
		frame.getContentPane().setBackground(Color.GRAY);
		frame.getContentPane().setForeground(new Color(255, 255, 255));
		frame.setBounds(150, 150, 504, 330);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Username:\r\n");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Trajan Pro", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(331, 11, 120, 34);
		frame.getContentPane().add(lblNewLabel);

		usernameField = new JTextField();
		usernameField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		usernameField.setBackground(SystemColor.controlHighlight);
		usernameField.setBounds(331, 56, 140, 25);
		frame.getContentPane().add(usernameField);
		usernameField.setColumns(10);

		passwordField = new JTextField();
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		passwordField.setBackground(SystemColor.controlHighlight);
		passwordField.setBounds(331, 126, 140, 25);
		frame.getContentPane().add(passwordField);
		passwordField.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setFont(new Font("Trajan Pro", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(331, 92, 120, 23);
		frame.getContentPane().add(lblNewLabel_1);
		JButton btnNewButton = new JButton("SignUp");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = usernameField.getText();
				String password = passwordField.getText();

				try {

					if (dialog.getText().equals("you are not welcome here")) {
						JButton button = (JButton) arg0.getSource();
						button.setEnabled(false);
						dialog.setText("You have been banned");
					} else {
						JButton button = (JButton) arg0.getSource();
						button.setEnabled(false);

						outToServer.writeObject(username);
						outToServer.writeObject(password);

						String message = (String) inFromServer.readObject();

						if (message.equals("access approved")) {
							dialog.setText("Welcome " + username);
						} else if (message.equals("ddos")) {
							dialog.setText("You have just been banned for a ddos attack");
						} else if (message.equals("enter credentials again")) {
							dialog.setText("Please enter your credentials again");
							button.setEnabled(true);
						} else if (message.equals("you are not welcome here")) {
							dialog.setText("You are not welcome here");
						}
					}

				} catch (SocketException e) {
					dialog.setText("You are not welcome here");
				} catch (UnknownHostException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}

			}
		});
		btnNewButton.setBackground(SystemColor.controlHighlight);
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Trajan Pro", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setBounds(365, 201, 106, 25);
		frame.getContentPane().add(btnNewButton);

		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(ClientFrame.class.getResource("/images/usp4.jpg")));
		lblNewLabel_2.setBounds(-12, -33, 506, 339);
		frame.getContentPane().add(lblNewLabel_2);
	}

}
