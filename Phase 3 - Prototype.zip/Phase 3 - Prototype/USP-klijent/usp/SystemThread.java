package usp;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class SystemThread extends Thread {

	ConcurrentHashMap<String, Integer> ddosDetection;
	ConcurrentHashMap<String, Integer> bruteforceDetection;
	ConcurrentHashMap<String, String> myUsers;

	public SystemThread(ConcurrentHashMap<String, String> myUsers,
			ConcurrentHashMap<String, Integer> bruteforceDetection, ConcurrentHashMap<String, Integer> ddosDetection) {
		this.myUsers = myUsers;
		this.bruteforceDetection = bruteforceDetection;
		this.ddosDetection = ddosDetection;
	}

	public void run() {
		while (true) {
			try {
				Thread.sleep(1800000); // half an hour
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			System.out.println(ddosDetection.toString());
			
			Iterator<Entry<String, Integer>> iterator = bruteforceDetection.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, Integer> mapElement = (Entry<String, Integer>) iterator.next();
				if ((int) mapElement.getValue() < 20) {
					mapElement.setValue(0);
				}
			}
			
			
			iterator = ddosDetection.entrySet().iterator();


			while (iterator.hasNext()) {
				Map.Entry<String, Integer> mapElement = (Entry<String, Integer>) iterator.next();
				if ((int) mapElement.getValue() < 20) {
					mapElement.setValue(0);
				}
			}

			System.out.println(ddosDetection.toString());
		}

	}

}
