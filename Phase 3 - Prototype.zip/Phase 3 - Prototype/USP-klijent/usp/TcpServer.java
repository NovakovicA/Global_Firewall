package usp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;

public class TcpServer {
	
	static ConcurrentHashMap<String, Integer> ddosDetection = new ConcurrentHashMap<String, Integer>();
	static ConcurrentHashMap<String, Integer> bruteforceDetection = new ConcurrentHashMap<String, Integer>();
	static ConcurrentHashMap<String, String> myUsers = new ConcurrentHashMap<String, String>();

	public static void main(String[] args) {

		try (ServerSocket server = new ServerSocket(53000)) {
			System.out.println("TcpServer started on port 53000");
			new SystemThread(myUsers,bruteforceDetection ,ddosDetection).start();; 
			myUsers.put("Drazen", "123"); //Hard coded for the purpose of an illustrative example
			while (true) {
				Socket client = server.accept();
				new WorkingThread(client, myUsers,bruteforceDetection ,ddosDetection).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}