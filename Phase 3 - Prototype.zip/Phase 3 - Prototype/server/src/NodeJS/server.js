const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
const cors = require("cors");
const server = express();



server.use(cors());
server.use(bodyParser.json());

mongoose.connect("mongodb://localhost:27017/DBUSP",{useNewUrlParser: true ,useUnifiedTopology: true,},(err)=>{
  if(!err) {
    console.log('Successfully connected to MongoDB.');
  }
  else{
    console.log("Error connecting to MongoDB: " + JSON.stringify(err,undefined,2));
  }
});

server.listen(3000, () => console.log("NodeJS server started on port: 3000"));

var User = require("./models/User");
var Report = require("./models/Report");

var supportedAttackTypes=["DoS","bruteforce"];
var activeBanTime=[10,31]; //ban time in days


const updateReports = setInterval(async function(){
  try{
    var reports = await Report.find({active:true});
    var currtime= new Date();
    reports.forEach(async function(r){
      var ind = supportedAttackTypes.indexOf(r.attackType);
      if(((currtime.getTime()-r.timeStamp.getTime())/(1000 * 3600 * 24))>activeBanTime[ind]){
        await Report.updateOne(r,{active:false});
      }
    });
  }
  catch(ex){
    console.log(ex.message);
  }
},5000);



server.post("/adduser",async function(req,res){
  try{
  var count = await User.find({username:req.body.admusername,password:req.body.admpassword,admin:true}).countDocuments();
  if(count==0){
    res.json("Invalid admin credentials.");
  }
else{
  count = await User.find({username:req.body.username}).countDocuments();
  if(count!=0){
    res.json("Username already registered.");
  }
else{
  var user = new User({
    "username":req.body.username,
    "password":req.body.password,
    "admin":req.body.admin
  });
  await user.save();
  res.json("User added successfully.");
}}}
catch(err){
  res.json("Error: " + err.message);
}
});


server.post("/removeuser",async function(req,res){
  try{
  var count = await User.find({username:req.body.admusername,password:req.body.admpassword,admin:true}).countDocuments();
  if(count==0){
    res.json("Invalid admin credentials.");
  }
else{
  count = await User.find({username:req.body.username}).countDocuments();
  if(count==0){
    res.json("Requested username could not be found.");
  }
else{
  await User.deleteOne({username:req.body.username});
  res.json("User deleted successfully.");
}}}
catch(err){
  res.json("Error: " + err.message);
}
});

server.post("/getusers",async function(req,res){
  try{
  var count = await User.find({username:req.body.username,password:req.body.password,admin:true}).countDocuments();
  if(count==0){
    res.json("Invalid admin credentials.");
  }
else{
  var users = await User.find({}).select("-__v").select("-_id");
  res.json(users);
}}
catch(err){
  res.json("Error: " + err.message);
}
});





server.post("/report",async function(req,res){
  try{
  var count = await User.find({username:req.body.username,password:req.body.password}).countDocuments();
  if(count==0){
    res.json("Invalid user credentials.");
  }
else{
  if(supportedAttackTypes.includes(req.body.attackType)){
    count =await Report.find({username:req.body.username,attackType:req.body.attackType,IPv4:req.body.IPv4,timeStamp:req.body.timeStamp}).countDocuments();
    if(count==0){
    var report = new Report({
    username:req.body.username,
    attackType:req.body.attackType,
    IPv4:req.body.IPv4,
    timeStamp:req.body.timeStamp,
    active:true
  });
  await report.save();
  res.json("Successfully saved report of an attack.");
}
else{
  res.json("Report about attack already submitted.");
}
}
else{
  res.json("Invalid attack type.");
}
  }}
catch(err){
  res.json("Error: " + err.message);
}
});



server.post("/checkclient",async function(req,res){
  try{
  var count = await User.find({username:req.body.username,password:req.body.password}).countDocuments();
  if(count==0){
    res.json("Invalid user credentials.");
  }
else{
  var rep = await Report.find({IPv4:req.body.IPv4,active:true});
  if(rep.length==0){
    res.json({"approved":true,"attackType":"","timeStamp":""});
  }
  else{
    var attackType;
    var timeStamp;
    rep.forEach((el)=>{attackType=el.attackType; timeStamp=el.timeStamp});
    res.json({"approved":false,"attackType":attackType,"timeStamp":timeStamp});
  }
  }}
catch(err){
  res.json("Error: " + err.message);
}
});

server.post("/login",async function(req,res){
  try{
  var user = await User.find({username:req.body.username,password:req.body.password});
  if(user.length==0){
    res.json("Invalid user credentials.");
  }
else{
  if(user[0].admin==true){
    res.json("Admin successfully logged in.");
  }
  else{
    res.json("User successfully logged in.")
  }
}
}
catch(err){
  res.json("Error: " + err.message);
}
});


server.post("/getreports",async function(req,res){
  try{
  var count = await User.find({username:req.body.username,password:req.body.password}).countDocuments();
  if(count==0){
    res.json("Invalid user credentials.");
  }
else{
 var reports=await Report.find({username:req.body.username});
  res.json(reports);
}}
catch(err){
  res.json("Error: " + err.message);
}
});
