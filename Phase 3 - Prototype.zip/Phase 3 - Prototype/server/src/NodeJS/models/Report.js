const mongoose = require("mongoose");
var Schema = mongoose.Schema;


var Report = mongoose.model("Report",new Schema({
  username:String,
  attackType:String,
  IPv4:String,
  timeStamp:Date,
  active:Boolean
}),"Reports");

module.exports = Report;
