import { ApiService } from './../api.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Report } from '../models/report';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private router:Router,private api:ApiService) { this.refresh = setInterval(()=>{this.getReports},5000);}

  User:string;
  Pass:string;

  reports:Report[]=[];
  refresh;

  ngOnInit(): void {
    if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
      this.getReports();
    }
  }

ngOnDestroy(){
  clearInterval(this.refresh);
}

  logout():void{
    localStorage.removeItem("User");
    localStorage.removeItem("Pass");
    this.router.navigate(['/login']);
  }

  getReports():void{
    this.api.getReports(this.User,this.Pass).subscribe(data=>{this.reports=data});
  }

  sort():Report[]{
    return this.reports.sort((a, b) => Number(b.active) - Number(a.active));
  }
}
