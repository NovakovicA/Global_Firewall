export class User{
  username:string;
  password:string;
  admin:boolean;
}
