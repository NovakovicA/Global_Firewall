export class Report{
  username:string;
  attackType:string;
  IPv4:string;
  timeStamp:Date;
  active:Boolean;
}
