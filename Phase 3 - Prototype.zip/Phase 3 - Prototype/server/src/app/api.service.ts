import { User } from './models/User';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Report } from './models/report';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) { }

  loginURL:string="http://localhost:3000/login";
  getUsersURL:string="http://localhost:3000/getusers";
  addUserURL:string="http://localhost:3000/adduser";
  removeUserURL:string="http://localhost:3000/removeuser";
  getReportsURL:string="http://localhost:3000/getreports";

  login(User:string,Pass:string):Observable<string>{
    let data={
      "username":User,
      "password":Pass
    }
    return this.http.post<string>(this.loginURL,data);
  }

  getUsers(User:string,Pass:string):Observable<User[]>{
    let data={
      "username":User,
      "password":Pass
    }
    return this.http.post<User[]>(this.getUsersURL,data);
  }

  addUser(admUser:string,admPass:string,User:string,Pass:string,admin:boolean):Observable<string>{
    let data={
      "username":User,
      "password":Pass,
      "admin":admin,
      "admusername":admUser,
      "admpassword":admPass
    }
    return this.http.post<string>(this.addUserURL,data);
  }

  removeUser(admUser:string,admPass:string,User:string):Observable<string>{
    let data={
      "username":User,
      "admusername":admUser,
      "admpassword":admPass
    }
    return this.http.post<string>(this.removeUserURL,data);
  }



  getReports(User:string,Pass:string):Observable<Report[]>{
    let data={
      "username":User,
      "password":Pass
    }
    return this.http.post<Report[]>(this.getReportsURL,data);
  }
}
