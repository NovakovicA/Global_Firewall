import { ApiService } from './../api.service';
import { User } from './../models/User';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router:Router,private api:ApiService) {this.refresh = setInterval(()=> { this.getUsers() }, 5000); }

  refresh;
  User:string;
  Pass:string;
  users:User[]=[];
  response:String;

  tempUser:User=new User;

  ngOnInit(): void {
    if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
      this.getUsers();
    }
  }

  logout():void{
    localStorage.removeItem("User");
    localStorage.removeItem("Pass");
    this.router.navigate(['/login']);
  }

  getUsers():void{
    this.api.getUsers(this.User,this.Pass).subscribe(data=>{
      this.users=data;
  });
  }

  removeUser(el:User){
    this.api.removeUser(this.User,this.Pass,el.username).subscribe(data=>{this.response=data;this.getUsers();});
  }

  addUser(el:User){
    this.api.addUser(this.User,this.Pass,el.username,el.password,el.admin).subscribe(data=>{this.response=data;this.getUsers();
    this.tempUser=new User;
    });
  }

}
